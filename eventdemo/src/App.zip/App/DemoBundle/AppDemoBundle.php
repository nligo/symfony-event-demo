<?php

namespace App\DemoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AppDemoBundle extends Bundle
{
}
